export class CreateLinkedIdentityDto{
     readonly NIN: number;
     readonly BVN: number;
     readonly MobileNumber: number;

     
}     
  